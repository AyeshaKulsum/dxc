import requests
from bs4 import BeautifulSoup

page=requests.get('https://github.com/trending')

#create beautiful soup object
soup= BeautifulSoup(page.text,'html.parser')

#get repo list
repo=soup.find(class_="explore-pjax-container container-lg p-responsive pt-6")

#repo=soup.find(class_="repo-list")


#repo-list
repo_list=repo.find_all(class_='Box-row')

print(len(repo_list))
print(repo_list)
