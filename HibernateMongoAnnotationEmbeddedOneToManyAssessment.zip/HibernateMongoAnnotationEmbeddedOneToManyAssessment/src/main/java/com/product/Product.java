package com.product;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.GenericGenerator;


@Entity
public class Product {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
	private String id;
	private String name;
	private int price;
	private int quantityOnHand;
	 @OneToMany(mappedBy = "productReviews", cascade = CascadeType.PERSIST)
	 private Set<Reviews> productReviews = new HashSet<Reviews>();
	 public Product() {
		// TODO Auto-generated constructor stub
	}
	 
	public Product(String id, String name, int price, int quantityOnHand, Set<Reviews> productReviews) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.quantityOnHand = quantityOnHand;
		this.productReviews = productReviews;
	}

	public Product(String name, int price, int quantityOnHand) {
		super();
		this.name = name;
		this.price = price;
		this.quantityOnHand = quantityOnHand;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantityOnHand() {
		return quantityOnHand;
	}
	public void setQuantityOnHand(int quantityOnHand) {
		this.quantityOnHand = quantityOnHand;
	}
	public Set<Reviews> getProductReviews() {
		return productReviews;
	}
	public void setProductReviews(Set<Reviews> productReviews) {
		this.productReviews = productReviews;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + ", quantityOnHand=" + quantityOnHand
				+ ", productReviews=" + productReviews + "]";
	}
	
	 

}
