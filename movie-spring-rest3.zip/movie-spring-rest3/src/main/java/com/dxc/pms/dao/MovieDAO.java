package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.Movies;

public interface MovieDAO {
	public boolean addMovie(Movies movie);
	public Movies getMovie(int movieId);
	public boolean deleteMovie(int movieId);
	public boolean upadteMovie(Movies movie);
	public List<Movies> getMovies();
	public boolean isMovieExists(int movieId);
	public List<Movies> searchMovieByName(String movieName);
}
