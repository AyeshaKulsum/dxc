import React, { Component } from 'react';
import ProductList from './ProductList';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import './App.css'
import Form from './Form';
import stockUpdate from './StockUpdate';


class ProductStockUpdate extends Component {
    render() {
        return (
            <div>
            <div>
                <h1>ProductStockUpdate</h1>
                <Router>
                <Route path="/productStockUpdate" 
                        render={({ match }) => match={match}} 
                        component={ProductList} />
                    </Router>
            </div>
           
           <Form></Form>
            </div>
        );
    }
}

export default ProductStockUpdate;