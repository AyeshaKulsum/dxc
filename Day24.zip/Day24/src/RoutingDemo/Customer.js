import React, { Component } from 'react';

class Customer extends Component {
    render() {
        return (
            <h1>Customer</h1>
        );
    }

}

export default Customer;