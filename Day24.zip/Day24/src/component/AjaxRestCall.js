
import React, { Component } from 'react'
//import './App.css'
import axios from 'axios'
class AjaxRestCall extends Component {
    constructor() {
        super()
        this.state = {
            username: '',
            value:''
        }
        this.handleClick = this.handleClick.bind(this)
    }
    handleClick(ourData) {
        this.setState( (
            {
               
                value:ourData.target.value
            }
        ))
        
    }
display(ourData)
{
    console.log("handleClick Called")
    axios.get('https://api.github.com/users/'+ourData.target.value)
        .then(response => this.setState({ username: response.data.followers_url }))
        ourData.preventDefault()
}
    render() {
        return (
            
            <div>
               Username <input type="text" value={this.state.value} onChange={this.handleClick}></input>
               <div className='btn'>
                <button className='button' onClick={this.display}>Click Me</button>
                <p>{this.state.username}</p>
            </div>
            </div>
           
        )
    }
}
export default AjaxRestCall;