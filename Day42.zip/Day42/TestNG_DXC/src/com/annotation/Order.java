package com.annotation;

import org.testng.annotations.Test;

public class Order {
	
	@Test(priority=1)
	public void compose()
	{
			//save mail
		System.out.println("compose mail");
	}
	@Test(priority=2)
	public void Savemail()
	{
			//save mail
		System.out.println("save mail");
	}
	@Test(priority=-1)
	public void Login()
	{
			//save mail
		System.out.println("Login");
	}
	
}
