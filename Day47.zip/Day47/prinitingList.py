list=[2*i for i in range(6)]

print(list)

print(*list)

print(*list,sep=" and ",end="--thats all\n")
