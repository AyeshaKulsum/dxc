package com.dxc.user.model;

public class UserForm {

	/*
	 * username password fullName gender qualification
	 */
}
