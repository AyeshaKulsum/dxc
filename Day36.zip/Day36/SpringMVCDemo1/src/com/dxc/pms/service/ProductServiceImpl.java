package com.dxc.pms.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.dxc.pms.dao.ProductDAO;
import com.dxc.pms.model.Product;

public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDAO productDAO;
	@Override
	public boolean addProduct(Product product) {
		System.out.println("Inside Service"+product);
		productDAO.addProduct(product);
		
		return false;
	}

}
