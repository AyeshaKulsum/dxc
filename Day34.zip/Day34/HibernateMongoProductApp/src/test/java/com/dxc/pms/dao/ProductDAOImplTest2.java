package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.Product;

import junit.framework.TestCase;

public class ProductDAOImplTest2 extends TestCase {
	ProductDAO productDAO;
	protected void setUp() throws Exception {
		productDAO=new ProductDAOImpl();
	}
	public void testGetProduct() {
		fail("Not yet implemented");
	}

	public void testGetAllProducts() {
		fail("Not yet implemented");
	}

	public void testAddProduct() {
		fail("Not yet implemented");
	}

	public void testDeleteProduct() {
		fail("Not yet implemented");
	}

	public void testUpdateProduct() {
		fail("Not yet implemented");
	}

	public void testIsProductExists() {
		fail("Not yet implemented");
	}

	public void testGetAllProductNames() {
		List<Product> p=productDAO.getAllProductNames("Bottle");
		System.out.println(p);
		assertEquals(true, true);
	}

}
