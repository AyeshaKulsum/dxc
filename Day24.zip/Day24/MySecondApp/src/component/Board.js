class Comment extends React.Component 
{
	constructor(props){
		super(props)
    this.edit = this.edit.bind(this)
    this.save = this.save.bind(this)
    this.remove = this.remove.bind(this)
    this.state = {editing: false}
  }
  edit(e){
    this.setState({editing:true})
    e.preventDefault()
  }
  remove(e){
    this.props.remove(this.props.index)
    e.preventDefault()
  }
  save(e) {
     this.setState({editing:false})
     this.props.update(this.refs.newValue.value, this.props.index)
    e.preventDefault()
  }
   renderNormal(){
    return(
        <div>
          <h1>{this.props.children}</h1>
          <button onClick={this.edit}>Edit</button>
	<button onClick={this.remove}>Remove</button>
        </div>
      )
  }
  renderForm(){
    return(
        <div>
          <textarea ref="newValue" defaultValue={this.props.children}></textarea>
          <button onClick={this.save}>Save</button>
          
        </div>
      )
  }
  render(){
   if (this.state.editing)
    	return this.renderForm()
    return this.renderNormal()
  }
}

class Board extends React.Component {
	constructor(props){
  	super(props)
    this.updateComment = this.updateComment.bind(this)
    this.removeComment = this.removeComment.bind(this)
        this.addButton = this.addButton.bind(this)
        this.setbackground = this.setbackground.bind(this)
    this.state = {
    	comments: [
      'Google ', 'Microsoft ', 'DXC '
      ],
      value:'',
      description:''
    }
  }
  removeComment(i){
     console.log("Removing Comment " + i)
    var arr = this.state.comments
    arr.splice(i, 1)
    this.setState({comments:arr})
  }
setbackground()
  {
  window.setTimeout( "setbackground()", 5000); // 5000 milliseconds delay
  
  var index = Math.round(Math.random() * 9);
  
  var ColorValue = "FFFFFF"; // default color - white (index = 0)
  
  if(index == 1)
  ColorValue = "FFCCCC"; //peach
  if(index == 2)
  ColorValue = "CCAFFF"; //violet
  if(index == 3)
  ColorValue = "A6BEFF"; //lt blue
  if(index == 4)
  ColorValue = "99FFFF"; //cyan
  if(index == 5)
   ColorValue = "D5CCBB"; //tan
  if(index == 6)
  ColorValue = "99FF99"; //lt green
  if(index == 7)
  ColorValue = "FFFF99"; //lt yellow
  if(index == 8)
  ColorValue = "FFCC99"; //lt orange
  if(index == 9)
  ColorValue = "CCCCCC"; //lt grey
  
  return ColorValue;
  
  }
  updateComment(newtext, i){
  console.log('updating ' + i)
  	var arr = this.state.comments
		arr[i] = newtext
    this.setState({comments:arr})
  }
  handleChange(event)
  {
    this.setState({
        value: event.target.value,
        description:event.target.value
    })
  }
	addButton(e){
        let ColorValue=''
        ColorValue=()=>{setbackground()};
        document.body.style.backgroundColor= "#" + ColorValue;
        if(e.target.value.length==0)
        {
            this.add('Default')
           
        }
		else{
            this.add(e.target.value)
            this.add(e.target.description)
        }
		e.preventDefault()
	}  

	  add(text)
	 {

		  console.log('tryin 2 add')
		   var arr = this.state.comments
		   arr.push(text)
		   this.setState({comments:arr})

	  }
	  render () {
  	return (
<form className="form-group container">
	    	<div className="form-control">
                
                <div className="btn">
                <input type="text" placeholder="Name" onChange={this.handleChange}></input>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="text" placeholder="description" onChange={this.handleChange}></input>
	      	<button ref='buttonToAdd' onClick={this.addButton} className="btn-success">Add</button>
		     <div className="row">
             <div className="col-md-12 col-md-offset-1 customDiv "> {
		        	this.state.comments.map((text, i)=>{
          	return <Comment update={this.updateComment} remove={this.removeComment} key={i} index={i} >{text}</Comment>
          })
        }</div></div>
        </div>
      </div>
      </form>
    )
  }
}

ReactDOM.render(
<Board/>,
  document.getElementById('eventHandling')
);