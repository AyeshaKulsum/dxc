import React, { Component } from 'react';
import productDataService from '../service/productDataService';
import {Formik,Form,Field} from 'formik';
class ProductComponent extends Component {
    constructor(props) {
        super(props);
        this.state=({
            productId:this.props.match.params.prodId,
            productName:'',
            quantityOnHand:'',
            price:''
        })

    }
    componentWillMount()
    {

        productDataService.getProductById(this.state.productId).then(
            response =>{
                this.setState({
                    productName:response.data.productName,
                    quantityOnHand:response.data.quantityOnHand,
                    price:response.data.price
                })
                    console.log(this.state.price);
                }
            
        )
    
    }
    render() {
        let{productId,productName,quantityOnHand,price}=this.state
        return (
            <div>
         {   /*    <h1>Add/Update</h1>
                <h3>Id to update{productId}</h3>
                <h3>{productName}
                
                
                </h3>
                <div>{quantityOnHand}</div>
                <div>{price}</div>*/}
                <div className="container">
                
                <Formik>
                    <Form>
                        <fieldset className="form-group">
                            <label>Product Id</label>
                            <Field className="form-control" type="text" name="productId"/>
                        </fieldset>
                        <fieldset className="form-group">
                            <label>Product Name</label>
                            <Field className="form-control" type="text" name="productName"/>
                        </fieldset>
                        <fieldset className="form-group">
                            <label>Quantity On Hand</label>
                            <Field className="form-control" type="text" name="quantityOnHand"/>
                        </fieldset>
                        <fieldset className="form-group">
                            <label>Price</label>
                            <Field className="form-control" type="text" name="price"/>
                        </fieldset>
                    </Form>
                </Formik>
                </div>
                
            </div>
        );
    }
}

export default ProductComponent;