package com.dxc.user.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.dxc.user.dao.UserFormDAO;
import com.dxc.user.dao.UserFormDAOImpl;
import com.dxc.user.model.UserForm;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String confirmpassword = request.getParameter("confirmpassword");
		String fullName = request.getParameter("fullName");
		String gender = request.getParameter("gender");
		String qualification = request.getParameter("qualification");
		UserForm userForm = new UserForm(username, password, confirmpassword, fullName, gender, qualification);
		UserFormDAO userFormDAO = new UserFormDAOImpl();
		userFormDAO.addUser(userForm);
		response.getWriter().println("<h1>User Added successfully</h1>");
		RequestDispatcher dispatcher =request.getRequestDispatcher("loginForm.html");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		doGet(request, response);
	}

}
