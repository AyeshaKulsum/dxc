def sum_range(n,m=100):
     sum=0
     for val in range(n,m+1):
          sum+=val
sum_range(1)
