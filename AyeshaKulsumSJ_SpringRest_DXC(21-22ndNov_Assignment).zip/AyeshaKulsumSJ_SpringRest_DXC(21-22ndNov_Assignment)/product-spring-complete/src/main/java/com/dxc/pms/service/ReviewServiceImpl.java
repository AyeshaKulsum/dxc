package com.dxc.pms.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dxc.pms.dao.ReviewDAO;
import com.dxc.pms.model.Product;
import com.dxc.pms.model.Reviews;
@Service
public class ReviewServiceImpl implements ReviewService {
	@Autowired
	ReviewDAO reviewDAO;
	@Override
	public boolean addReview(int productId, Reviews review) {
		// TODO Auto-generated method stub
		return reviewDAO.addReview(productId, review);
	}

	@Override
	public Reviews getReview(int productId,int reviewId) {
		// TODO Auto-generated method stub
		return reviewDAO.getReview(productId,reviewId);
	}

	@Override
	public boolean isReviewExists(int reviewId) {
		// TODO Auto-generated method stub
		return reviewDAO.isReviewExists(reviewId);
	}

	@Override
	public boolean deleteReview(int productId,int reviewId) {
		// TODO Auto-generated method stub
		return reviewDAO.deleteReview(productId,reviewId);
	}

	@Override
	public boolean updateReview(int productId,Reviews review) {
		// TODO Auto-generated method stub
		return reviewDAO.updateReview(productId,review);
	}

	@Override
	public Set<Reviews> getReviews(int productId) {
		// TODO Auto-generated method stub
		return  reviewDAO.getReviews(productId);
	}

}
