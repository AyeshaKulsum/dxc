package com;

public class Employee {
		private String employeeName;

		public Employee() {
			System.out.println("Employee default constructor called");
		}

		public String getEmployeeName() {
			return employeeName;
		}

		public void setEmployeeName(String employeeName) {
			this.employeeName = employeeName;
		}
		
}
