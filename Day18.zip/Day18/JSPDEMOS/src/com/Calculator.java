package com;

public class Calculator {

	public Calculator() {
		// TODO Auto-generated constructor stub
	}
public int checkMax(int num1,int num2)
{
	if(num1>num2)
	{
		return num1;
	}
	else
	{
		return num2;
	}
}
}
