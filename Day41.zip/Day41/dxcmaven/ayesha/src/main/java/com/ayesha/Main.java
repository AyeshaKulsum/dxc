package com.ayesha;

/**
 * Hello world!
 *
 */
public class Main 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        App app =new App();
        System.out.println(app.message("Ayesha"));
    }
}
