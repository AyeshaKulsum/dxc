package com.product;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


import org.hibernate.annotations.GenericGenerator;



@Entity
public class Reviews {
	@Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
	private String id;
	private String text;
	private int rating;
	@ManyToOne
    private Product productReviews;

  
    public Reviews() {
		// TODO Auto-generated constructor stub
	}
	public Reviews(String id, String text, int rating, Product productReviews) {
		super();
		this.id = id;
		this.text = text;
		this.rating = rating;
		this.productReviews = productReviews;
		
	}
	public Reviews(String text, int rating) {
		super();
		this.text = text;
		this.rating = rating;
		
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public Product getProductReviews() {
		return productReviews;
	}
	public void setProductReviews(Product productReviews) {
		this.productReviews = productReviews;
	}

	@Override
	public String toString() {
		return "Reviews [id=" + id + ", text=" + text + ", rating=" + rating + ", productReviews=" + productReviews
				+ "]";
	}
    
}
