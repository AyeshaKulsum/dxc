def f():
    #global s
    s="Me too."
    print(s)
s="I love python"
f()
print(s)
