package com.dxc.pms.dao;

import java.util.List;


import com.dxc.pms.model.Product;

import junit.framework.TestCase;

public class ProductDAOImplTest extends TestCase {
ProductDAOImpl impl;
@Override
	protected void setUp() throws Exception {
		impl= new ProductDAOImpl();
	}
	public void testGetProduct() {
		
		Product product =new Product(1223, "phone", 23, 23001);
		impl.addProduct(product);
		Product product2 =impl.getProduct(1223);
		assertNotNull(product2);
	}

	public void testGetAllProducts() {
		int size1=impl.getAllProducts().size();
		Product product =new Product(901, "phone", 23, 23000);
		impl.addProduct(product);
		int size2=impl.getAllProducts().size();
		assertNotSame(size2,size1);
	}

	public void testAddProduct() {
		Product product =new Product(1000, "phone", 23, 23000);
		List <Product> allproducts1=impl.getAllProducts();
		impl.addProduct(product);
		List <Product> allproducts2=impl.getAllProducts();
		assertNotSame(allproducts2.size(), allproducts1.size());
	}

	public void testDeleteProduct() {
		
		Product product =new Product(401, "phone", 23, 23000);
		impl.addProduct(product);
		int size1=impl.getAllProducts().size();
		impl.deleteProduct(101);
		int size2=impl.getAllProducts().size();
		assertEquals(size2+1,size1);
	}

	public void testUpdateProduct() {
		
		Product product =new Product(9981, "phone", 23, 23000);
		impl.addProduct(product);
		List <Product> allproducts1=impl.getAllProducts();
		Product newProduct =new Product(9981, "went", 23, 23000);
		impl.updateProduct(newProduct);
		List <Product> allproducts2=impl.getAllProducts();
		
		assertNotSame(allproducts2,allproducts1);
	}

	public void testIsProductExists1() {
		Product product =new Product(12, "phone", 23, 23000);
		impl.addProduct(product);
		assertEquals(true,impl.isProductExists(12));
	}
	public void testIsProductExists2() {
		Product product =new Product(1001, "phone", 23, 23000);
		impl.addProduct(product);
		impl.deleteProduct(1001);
		assertEquals(false,impl.isProductExists(1001));
	}
}
