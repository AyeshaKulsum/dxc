package com.dxc.pms.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.pms.model.Product;
import com.pms.util.HibernateUtil;

public class ProductDAOImpl implements ProductDAO {
SessionFactory sf =HibernateUtil.getSessionFactory();
	@Override
	public Product getProduct(int productId) {
		Session session = sf.openSession();
		Product product =(Product)session.get(Product.class, productId);
		Transaction transaction=session.beginTransaction();
		product.setPrice(98000);
		transaction.commit();
		session.close();
		return product;
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getAllProducts() {
		Session session = sf.openSession();
		Query query=session.createQuery("from Product");
		return query.list();
	}

	@Override
	public void addProduct(Product product) {
		Session session = sf.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(product);
		transaction.commit();
		System.out.println(product.getProductName()+" saved successfully");
		session.close();
	}

	@Override
	public void deleteProduct(int productId) {
		Session session = sf.openSession();
		
		Transaction transaction=session.beginTransaction();
		//Product product =(Product)session.get(Product.class, productId);
		Product product=new Product();
		product.setProductId(productId);
		session.delete(product);
		transaction.commit();
		System.out.println(" deleted successfully");
		session.close();
	}

	@Override
	public void updateProduct(Product newProduct) {
		Session session = sf.openSession();
		
		Transaction transaction=session.beginTransaction();
		session.update(newProduct);
		/*Product oldProduct =(Product)session.get(Product.class, newProduct.getProductId());
		oldProduct.setProductName(newProduct.getProductName());
		oldProduct.setQuantityOnHand(newProduct.getQuantityOnHand());
		oldProduct.setPrice(newProduct.getPrice());*/
		transaction.commit();
		
		System.out.println(newProduct.getProductName()+" updated successfully");
		session.close();
	}

	@Override
	public boolean isProductExists(int productId) {
		Session session = sf.openSession();
		Product product =(Product)session.get(Product.class, productId);
		if(product==null)
		{
			session.close();
			return false;
		}
		else
			session.close();
		return true;
		
	}

	@Override
	public List<String> getAllProductNames() {
		Session session =sf.openSession();
		Query query =session.createQuery("select p.productName from Product p");
		List<String> pr=query.list();
		Iterator<String> iterator = pr.iterator();
		while(iterator.hasNext())
		{
			String p=iterator.next();
			System.out.println(p);
		}
		return pr;
	}

	@Override
	public List<Product> getAllProductNames(String productName) {
		Session session = sf.openSession();
		Query query=session.getNamedQuery("findProductByName");
		query.setString("prodName", productName);
		return query.list();
	}


}
