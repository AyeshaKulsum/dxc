package com.dxc.doctor.client;


import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.ogm.cfg.OgmConfiguration;

import com.dxc.doctor.model.Doctor;
import com.dxc.doctor.model.HospitalDetails;
import com.dxc.doctor.util.HibernateUtil;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	SessionFactory factory=HibernateUtil.getSessionFactory();
    	Session session =factory.openSession();
    	Transaction transaction = session.beginTransaction();
    	HospitalDetails details1=new HospitalDetails("Manipal", "Salem");
    	HospitalDetails details2=new HospitalDetails("St.Johns", "Banglore");
    	HospitalDetails details3=new HospitalDetails("Narayana", "Banglore");
    	Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
    	alldetails.add(details2);
    	alldetails.add(details3);
    	Doctor doctor = new Doctor("Ayesha", 901000, alldetails);
    	session.save(doctor);
    	transaction.commit();
    	System.out.println("Its Done");
    }
	
}
