num1=input('Please enter an integer value :')
num2=input('Please enter another integer value :')
print(num1,'+',num2,'=',num1+num2)
