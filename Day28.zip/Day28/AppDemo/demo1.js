var express=require("express")
var app=express()
app.set('view engine','ejs')
/* app.get("/",function(request,response){
    response.render("index")
}) */
app.get("/",function(request,response){
    response.sendFile(__dirname,'/index.html')
})
app.get("/product",function(request,response){
    response.send("Hello and Welcome to express get2 product")
})
app.get("/profile/:name",function(request,response){
    var data ={age:21,job:'consultant',hobbies:['eating','travelling','movies']}
    response.render('profile',{person:request.params.name,data:data})
})
app.get("/product/:pId/order/:oId",function(request,response){
   // response.send("Product Details for product id:"+request.params.pId+"Order details are:"+request.params.oId)
    response.render("product",{datapId:request.params.pId,dataoId:request.params.oId})
})
app.put("/productUpdate",function(request,response){
    response.send("Hello and Welcome to express productUpdate")
})
app.post("/productSave",function(request,response){
    response.send("Hello and Welcome to express productSave")
})
app.delete("/delete",function(request,response){
    response.send("Hello and Welcome to express delete")
})


console.log("Server started on port:  5001")
app.listen(5001)