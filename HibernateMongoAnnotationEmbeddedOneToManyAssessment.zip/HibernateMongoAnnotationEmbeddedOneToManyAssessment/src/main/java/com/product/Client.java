package com.product;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.ogm.cfg.OgmConfiguration;

public class Client {
	public static void main(String[] args) {

		OgmConfiguration cfg = new OgmConfiguration();
		cfg.configure();

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		Transaction tx = session.beginTransaction();

		Product product=new Product("Phone", 67000, 98);
		Reviews review1 = new Reviews("Nice", 5);
		Reviews review2 = new Reviews("Awesome", 10);

		review1.setProductReviews(product);
		product.getProductReviews().add(review1);
		review2.setProductReviews(product);
		product.getProductReviews().add(review2);


		session.save(review1);
		session.save(review2);
		session.save(product);

		tx.commit();
		System.out.println("Saved .. One to Many ");

	}
}
