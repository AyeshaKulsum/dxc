package com.annotation;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class OnemoreAssert {
	@Test
	public void testcase1() {
		SoftAssert st=new SoftAssert();
		String Expstr="Banglore";
		String Actstr="Bengaluru";
		System.out.println("A");
		if(!Expstr.equals(Actstr))
		{
			st.fail("Strings are mis-matching");
		}
		System.out.println("B");
		st.assertAll();
	}
}
