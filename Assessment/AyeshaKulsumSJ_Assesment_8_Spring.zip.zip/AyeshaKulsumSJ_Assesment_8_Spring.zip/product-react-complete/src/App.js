import React, { Component } from 'react';
import ListProductComponent from './components/ListProductComponent';
import {BrowserRouter as Router,Route,Switch} from 'react-router-dom';
import ProductComponent from './components/ProductComponent';
import SearchComponent from './components/SearchComponent';
import DisplayComponent from './components/DisplayComponent';

class App extends Component {
  render() {
    return (
      <div>
        <h1>Product App</h1>
        <Router>
          <Switch>
          <Route exact path="/" component={ListProductComponent}></Route>
          <Route exact path="/products" component={ListProductComponent}></Route>
          <Route  exact path="/products/:prodId" component={ProductComponent}></Route>
          <Route  exact path="/productsearch" component={SearchComponent}></Route>
          <Route path="/productSearch/:prodName" component={DisplayComponent}></Route>
          </Switch>
          
        </Router>
        
      </div>
    );
  }
}

export default App;