import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';
import {Formik,Form,Field, ErrorMessage} from 'formik';
import ListProductComponent from './ListProductComponent';
import '../App.css';
class DisplayComponent extends Component {
        constructor(props) {
        super(props);
        this.state=({
            products:[],
            productName:this.props.match.params.prodName, 
        })
        this.homeButtonClicked=this.homeButtonClicked.bind(this)
    }
    componentWillMount()
    {
            ProductDataService.getProductByName(this.state.productName).then(
                response =>{
                    this.setState({
                        products:response.data
                    })
                    }
                
            )
            }
            homeButtonClicked(){
                this.props.history.push(`/products`)
            }
    render() {

        return (
            <div>

                
                <div className="container">
                <h1>Searched Product</h1>
                        <table className="table">
                            <thead>
                            <tr>
                                <th>Product Id</th>
                                <th>Product Name</th>
                                <th>Quantity On Hand</th>
                                <th>Price</th>
                                
                                
                            </tr>

                            </thead>
                            <tbody>
                            {
                                this.state.products.map(product=>
                                    <tr key={product.productId}>
                                        <td>{product.productId}</td>
                                        <td>{product.productName}</td>
                                        <td>{product.quantityOnHand}</td>
                                        <td>{product.price}</td>
                                          </tr>
                                    
                                    )
                            }
                          

                            </tbody>
                            <tr><td><button className="btn btn-warning" onClick={()=>this.homeButtonClicked()}>Home</button></td></tr>
                        </table>
                </div>
        </div>
            
            
        );
    }
}

export default DisplayComponent;