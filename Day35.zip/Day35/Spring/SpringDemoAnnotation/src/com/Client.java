package com;



import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class Client {
public static void main(String[] args) {
	ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
	
	Employee e =(Employee) context.getBean(Employee.class);
	Address a =(Address) context.getBean(Address.class);
	
	e.setEmpId(1);
	e.setEmpName("Saif");
	e.setSalary(90000);
	
	a.setCity("Chennai");
	a.setState("Karnataka");
	e.setAddress(a);
	System.out.println(e);
}
}
