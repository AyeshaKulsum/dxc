print("This is a simple python program")
