import React, { Component } from 'react';

class App extends Component {
  constructor(props) {
    super(props);
    this.state=({
      message:''
    })
  }
callAPI()
{
  fetch("http://10.231.139.204:5000/myName").then(res=>res.text()).then(res=>this.setState({
    message:res
  }))
}  
componentWillMount()
{
  this.callAPI()
}
  render() {
    return (
      <div>
        <h1>Message received from Node is : {this.state.message}</h1>
      </div>
    );
  }
}

export default App;