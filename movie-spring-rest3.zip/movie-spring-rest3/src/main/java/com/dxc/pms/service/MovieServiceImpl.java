package com.dxc.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dxc.pms.dao.MovieDAO;
import com.dxc.pms.model.Movies;
@Service
public class MovieServiceImpl implements MovieService {
@Autowired
MovieDAO movieDAO;
	@Override
	public boolean addMovie(Movies movie) {
		
		return movieDAO.addMovie(movie);
	}

	@Override
	public Movies getMovie(int movieId) {
		
		return movieDAO.getMovie(movieId);
	}

	@Override
	public boolean deleteMovie(int movieId) {
	
		return movieDAO.deleteMovie(movieId);
	}

	@Override
	public boolean upadteMovie(Movies movie) {
		
		return movieDAO.upadteMovie(movie);
	}

	@Override
	public List<Movies> getMovies() {
		
		return movieDAO.getMovies();
	}

	@Override
	public boolean isMovieExists(int movieId) {
	
		return movieDAO.isMovieExists(movieId);
	}

	@Override
	public List<Movies> searchMovieByName(String movieName) {
		
		return movieDAO.searchMovieByName(movieName);
	}

}
