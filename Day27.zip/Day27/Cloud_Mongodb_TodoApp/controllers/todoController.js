var data = [];
var mongoose = require("mongoose")
//connection cloud
mongoose.connect("mongodb://tufail:ahmed123@ds339348.mlab.com:39348/todoappdxc")
//schema
var todoSchema = new mongoose.Schema({
    item: String
})

//Model
var Todo = mongoose.model('Todo', todoSchema)

const bodyParser = require('body-parser')
module.exports = function (app) {
app.use(
    bodyParser.urlencoded({
        extended:true
    })
)
app.use(bodyParser.json())
    app.get('/todo', function (request, response) {
        Todo.find(function(err,d){
            data =d;
        })
        console.log(data)
        response.render("todo", { todos: data });


    });

    app.post('/todo', function (request, response) {
        var itemName=request.body.itemName
        console.log("Item entered is:"+itemName)
                //adding the item in mongo db database
                var oneItem = Todo({ item: itemName }).save(function (err) {
                    if (err)
                        console.error(err);
                    console.log("item saved");
                })
                response.render("todo", { todos: data });
      //  response.send("TODO POST")
    });
    app.delete('/todo', function (request, response) {
        response.send("TODO DELETE")
    });
};
