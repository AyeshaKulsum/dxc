package com.dxc.client;

import junit.framework.TestCase;

public class AddNumbersTest extends TestCase {

	public void testSum() {
		AddNumbers number=new AddNumbers();
		int res=number.sum(1,1);
		assertEquals(2,res);
	}
	public void testSum1() {
		AddNumbers number=new AddNumbers();
		int res=number.sum(2,2);
		assertEquals(4,res);
	}
	public void testSum2() {
		AddNumbers number=new AddNumbers();
		int res=number.sum(4,6);
		assertEquals(10,res);
	}
	public void testSum3() {
		AddNumbers number=new AddNumbers();
		int res=number.sum(10,10);
		assertEquals(20,res);
	}
}
