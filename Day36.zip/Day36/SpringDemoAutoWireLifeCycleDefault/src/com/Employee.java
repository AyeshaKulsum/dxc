package com;



public class Employee  {
	private int empId;
	private String empName;
	private int salary;
	private Address address;
	private Project project;
	private Spouse spouse;
	public Employee() {
		System.out.println("Default called ");
	}

	public Employee(int empId, String empName, int salary, Address address, Project project, Spouse spouse) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.address = address;
		this.project = project;
		this.spouse = spouse;
	}
	
	public void start()
	{
		System.out.println("########STARTED");
	}
	public void end()
	{
		System.out.println("########END");
	}

	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public Spouse getSpouse() {
		return spouse;
	}

	public void setSpouse(Spouse spouse) {
		this.spouse = spouse;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", salary=" + salary + ", \naddress=" + address
				+ ", \nproject=" + project + ", \nspouse=" + spouse + "]";
	}
	
}
