import React from 'react';
export default function Welcome(props)
{
    return <h1>Welcome {props.name}{props.place}</h1>
}