var http=require("http")
function onRequest(request,response){
    response.writeHead(200,{"Content-type":"text-plain"})
    response.write("Today is good day")
    response.end()
}
var server =http.createServer(onRequest)
server.listen(8888)
console.log("Server 2 started on port 8888")