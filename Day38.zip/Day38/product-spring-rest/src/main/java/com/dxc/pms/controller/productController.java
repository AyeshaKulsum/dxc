package com.dxc.pms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.pms.dao.ProductDAO;
import com.dxc.pms.model.Product;
import com.dxc.pms.service.ProductService;

@RestController
@RequestMapping("/product")
@CrossOrigin(origins= {"http://localhost:3000","http://localhost:4200"})
public class productController {
	@Autowired
	ProductService productService;
	//getting a single product
	@GetMapping("/{productId}")
	
	public Product getProduct(@PathVariable("productId")int productId) {
		System.out.println("Get 1 called"+productId);
		return productService.getProduct(productId);
	}
	//deleting product
	@DeleteMapping("/{productId}")
	
	public boolean deleteProduct(@PathVariable("productId")int productId) {
		System.out.println("deleting called"+productId);
		return productService.deleteProduct(productId);
	}
	//get all products
		@GetMapping
		public List<Product> getAllProducts() {
			System.out.println("Fetching all products");
			return productService.getProducts();
		}
		//add product
				@PostMapping
				public boolean addProduct(@RequestBody Product product) {
					System.out.println(product);
					return productService.addProduct(product);
				}
				//update product
				@PutMapping
				public boolean updateProduct(@RequestBody Product product) {
					System.out.println(product);
					return productService.updateProduct(product);
				}	
			/*	@GetMapping("/{productName}")
				public List<Product> searchProduct(@PathVariable("productName")String productName) {
					return productService.searchProductByName(productName);
				}*/
	//demo
	@RequestMapping("/getProduct/{productId}/{oId}")
	public Product getProduct2(@PathVariable("productId")int productId,@PathVariable("oId")int oId) {
		System.out.println("Get 1 called productId: "+productId+" orderId: "+oId);
		return productService.getProduct(productId);
	}
	//demo
	@RequestMapping("/getProduct/pp")
	public Product getProduct() {
		System.out.println("pp called");
		return productService.getProduct(1234);
	}
	/*
	 * @RequestMapping("/productSave") public ModelAndView productForm(Product
	 * product) { System.out.println("Inside controller"+product);
	 * productService.addProduct(product); return new
	 * ModelAndView("success","product",product); }
	 */
}
