package com.annotation;


import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class SoftAssertEx {
	@Test
	public void testcase1() {
		SoftAssert st=new SoftAssert();
		int Explinks=10;
		int Actlinks=12;
		System.out.println("A");
		st.assertEquals(Actlinks, Explinks,"comparing number of links");
		st.assertEquals("Banglore", "Bengaluru","comparing two strings");
		System.out.println("B");
		st.assertAll();
		System.out.println("C");
	}
}
