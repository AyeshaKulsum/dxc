package com.dxc.movie.dao;

import java.util.List;

import com.dxc.model.Movies;


import junit.framework.TestCase;

public class MovieDAOImplTest extends TestCase {
MovieDAOImpl impl;
@Override
	protected void setUp() throws Exception {
		impl=new MovieDAOImpl();
	}
	public void testGetMovie() {
		Movies movie = new Movies(11, "Kal ho", 1234, "who know");
		impl.addMovie(movie);
		Movies movie2=impl.getMovie(1);
		assertNotNull(movie2);
	}

	public void testGetAllMovies() {
		int size1=impl.getAllMovies().size();
		Movies movie = new Movies(21, "Yesterday", 22393838, "me");
		impl.addMovie(movie);
		int size2=impl.getAllMovies().size();
		assertNotSame(size2, size1);
	}

	public void testAddMovie() {
		int size1=impl.getAllMovies().size();
		Movies movie = new Movies(31, "Mission", 22393838, "Akshay");
		impl.addMovie(movie);
		int size2=impl.getAllMovies().size();
		assertNotSame(size2, size1);
	}


	public void testDeleteMovie() {
		Movies movie = new Movies(41, "Mission", 22393838, "Akshay");
		impl.addMovie(movie);
		int size1=impl.getAllMovies().size();
		impl.deleteMovie(4);
		int size2=impl.getAllMovies().size();
		assertEquals(size2+1, size1);
	}

	public void testUpdateMovie() {
		Movies movie = new Movies(51, "Phone", 3287834, "No");
		impl.addMovie(movie);
		List <Movies> allmovies=impl.getAllMovies();
		Movies movie2 = new Movies(51, "Kalho Naho", 74378583, "Sharukh");
		impl.updateMovie(movie2);
		List <Movies> allmovies2=impl.getAllMovies();
		assertNotSame(allmovies2, allmovies);
	}

	public void testIsMovieExists1() {
		Movies movie = new Movies(61, "same", 333, "jsdjnmd");
		impl.addMovie(movie);
		assertEquals(true, impl.isMovieExists(6));
	}
	public void testIsMovieExists2() {
		Movies movie = new Movies(71, "same", 333, "jsdjnmd");
		impl.addMovie(movie);
		impl.deleteMovie(71);
		assertEquals(false, impl.isMovieExists(71));
	}

}
