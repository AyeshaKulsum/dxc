package com.dxc.pms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.pms.dao.ProductDAO;
import com.dxc.pms.model.Product;
import com.dxc.pms.service.ProductService;
@RestController
public class productController {
	@Autowired
	ProductService productService;
	@RequestMapping("/getProduct")
	public Product getProduct() {
		return productService.getProduct(1234) ;
	}
/*	@RequestMapping("/productSave")
public ModelAndView productForm(Product product)
{
		System.out.println("Inside controller"+product);
		productService.addProduct(product);
		return new ModelAndView("success","product",product);
}*/
}
