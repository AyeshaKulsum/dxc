function route(pathname,handle,response,postData)
{
if(typeof handle[pathname]=='function')
{
    console.log("Hello I am Routing :"+pathname)
    handle[pathname](response,postData)
}
else{
    console.log("Sorry no handlers founf for :"+pathname)
}
    /* console.log("2.Your request would be routed to:"+pathname)
    if(pathname==='/update')
    {
        console.log("3.Your request would be pathanme to:"+pathname)
    }
    else
    {
        console.log("3.Your request would be other routed to:"+pathname)
    } */
}
exports.route=route