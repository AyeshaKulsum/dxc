def sum(*nums):
    s=0
    for num in nums:
        s+=num
    return s
print(sum(3,4))
print(sum(3,4,5))
print(sum(1,2,3,4,5))
