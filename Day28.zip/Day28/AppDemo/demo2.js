let a=3
console.log(a)
function start()
{
    a=2
    console.log(a)
}
start()
console.log(a)