var fs=require("fs")
fs.readFile("Hello.txt","utf8",function(err,data)
{
  /*   if(err)
    {
        console.log(err.message)
    } */
    console.log(data)
})
console.log("Done")
