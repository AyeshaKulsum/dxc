print('A',end='')
print('B',end='')
print('C',end='')
