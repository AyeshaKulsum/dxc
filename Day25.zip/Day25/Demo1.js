console.log("Hello all");
//console.log(_dirname)
var time=0;

var timer=setInterval(function()
{
    time +=2;
    console.log(time +"seconds have passed")
    if(time>5)
    {
        clearInterval(timer)
    }
},2000)
var counter = function(arr)
{
return "there are" + arr.length + " elements in this array";
};
var adder = function(a,b)
{
    return "The Sum of the 2 numbers :"+ a+b; 
    //return `The Sum of the 2 numbers : ${a+b}`; 
};
var pi=3.14;
module.exports.counter = counter;
module.exports.adder = adder;
module.exports.pi=pi