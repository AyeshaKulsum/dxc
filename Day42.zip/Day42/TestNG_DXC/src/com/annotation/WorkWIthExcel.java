package com.annotation;

import org.testng.annotations.Test;

import xls.ShineXlsReader;

public class WorkWIthExcel {
	@Test
public void WorkWithEx()
{
	ShineXlsReader xls=new ShineXlsReader("TestData.xlsx");
	//ShineXlsReader xls=new ShineXlsReader(".\\TestData.xlsx");
	//if xlsx file is in src com package
	//ShineXlsReader xls=new ShineXlsReader(".\\src\\com\\annotation\\TestData.xlsx");
	int rowCount = xls.getRowCount("Sheet1");
	int columnCount = xls.getColumnCount("Sheet1");
	for(int i=2;i<=rowCount;i++)
	{
		for(int j=0;j<columnCount;j++)
		{
			String cellData = xls.getCellData("Sheet1", j, i);
			System.out.println(cellData);
		}
	}
}
}
