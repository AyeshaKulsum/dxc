package com.selConcepts;

import java.io.File;
import java.util.concurrent.TimeUnit;


import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class WorkWithSelObjects {
	public WebDriver driver;
	public String Browser="chrome";
	@Test
	public void testcase1() throws Throwable{
		SoftAssert st=new SoftAssert();
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver=new ChromeDriver(); //OpenBrowser
		}else if(Browser.equalsIgnoreCase("mozilla")){
			System.setProperty("webdriver.firefox.marionette", "geckodriver.exe");
			 driver=new FirefoxDriver();
		}else if(Browser.equalsIgnoreCase("ie")){
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			 driver=new InternetExplorerDriver();
		}
		
		driver.get("https://www.timesjobs.com/candidate/register.html?pageFlow=TJ_HOME"); //open url
		//driver.get("http://in5cg9214xt8:9000/login.do");
		driver.manage().window().maximize(); //maximize browser
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//Go
		
		WebElement sel = driver.findElement(By.xpath("//select[@id='curLocation']"));
		Select s=new Select(sel);
		//s.selectByIndex(3);
		s.selectByValue("198305");
		//s.selectByVisibleText("Delhi");
		//driver.findElement(By.xpath("//select[@id='curLocation']")).sendKeys("Chennai");
		File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(srcFile,new File("Src1.png"));
		
		//close browser
		//driver.quit();
		//driver.close();
		//st.assertAll();
}
}
