const products = [
  {
    id: 01,
    name: 'Laptop',
    available_quantity: 5,
    price: 450,
    description: 'Hardware device '
  },

  {
    id: 02,
    name: 'Lakme',
    available_quantity: 7,
    price: 50,
    description: 'Beauty Cream'
  },

  {
    id: 03,
    name: 'Mobile',
    available_quantity: 0,
    price: 500,
    description: 'One Plus Mobile'
  },

  {
    id: 04,
    name: 'Bottle',
    available_quantity: 4,
    price: 1500,
    description: 'Used for drinking water'
  },
];



const users = [
    {
      'name': 'tufail',
      'password': 'ahmed'
    },
    {
      'name': 'neha',
      'password': 'agrawal'
    }
];

module.exports = { 'products': products, users: users }