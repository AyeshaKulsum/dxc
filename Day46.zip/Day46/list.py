lst=[1,2,3,4,5,6,7,8]
print(lst)
lst[2:5]=['a','b','c']
print(lst)
 
