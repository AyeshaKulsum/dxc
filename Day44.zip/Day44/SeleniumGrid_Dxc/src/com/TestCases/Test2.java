package com.TestCases;

import org.testng.annotations.Test;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Test2 {
	//public WebDriver driver;
	public DesiredCapabilities cap;
	@Test(dataProvider="getdata")
   public void testCase1(String cn,String cp,String Browser) throws Throwable {
		System.out.println("Browser= "+Browser);
		
		cap=DesiredCapabilities.chrome();
		cap.setBrowserName("chrome");
		cap.setPlatform(Platform.ANY);
		//System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		//driver=new ChromeDriver(); //OpenBrowser
		WebDriver driver=new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"),cap);
		driver.get("http://localhost:9000/login.do");
		driver.manage().window().maximize(); //maximize browser
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		WebElement username=driver.findElement(By.xpath("//input[@name='username']"));
		username.sendKeys(cn);
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys(cp);
		Thread.sleep(3000);
		driver.quit();
   }
	
	@DataProvider(parallel=true)
	public Object[][] getdata(){
		Object obj[][]=new Object[3][3];
		obj[0][0]="Name1";
		obj[0][1]="Password1";
		obj[0][2]="chrome";
		
		obj[1][0]="Name2";
		obj[1][1]="Password2";
		obj[1][2]="chrome";
		
		obj[2][0]="Name3";
		obj[2][1]="Password3";
		obj[2][2]="chrome";
		
		return obj;
		
	}
}