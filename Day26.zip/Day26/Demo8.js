var fs=require('fs')
var myReadStream = fs.createReadStream(__dirname+'/readMe.txt','utf-8')
var myWriterStream = fs.createWriteStream(__dirname+'/writeMe22.txt')
myReadStream.pipe(myWriterStream)
