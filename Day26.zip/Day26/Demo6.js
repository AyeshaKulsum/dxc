var fs=require('fs')
fs.mkdir('DXC',function()
{
    fs.mkdir('./DXC/Cust',function()
    {
        fs.mkdir('./DXC/Cust/Emp',function()
{
    fs.readFile("readMe.txt",'utf-8',function(err,data){
        fs.writeFileSync('./DXC/Cust/Emp/data.txt',data)
    })
})
    }) 
})