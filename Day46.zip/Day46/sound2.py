import org.jfugue.*;

public class JingleBells
{
    public static void main(String[] args)
    {
        Player player = new Player();
        player.play("T170 "+
                    "     V0 I[XYLOPHONE] C4q C4q C3h C4q C4q C3h C3q B3q A3q G3q C4h "+
                    "     V1 I[TUBULAR_BELLS] E5q E5q E5h E5q E5q E5h E5q G5q C5q D5q Eqh "+
                    "     V2 I[XYLOPHONE] G3h     G2q G3q G3h     G3h");
    }
}
