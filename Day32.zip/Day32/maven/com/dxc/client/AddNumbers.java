package com.dxc.client;

public class AddNumbers {
public int sum(int num1,int num2)
{
	return num1+num2;
}
}
