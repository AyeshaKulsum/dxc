function start(response)
{
    console.log("Request handler 'start' was called.");
    var body = '<html>' +
        '<head>' +
        '<meta http-equiv="Content-Type" content="text/html; ' +
        'charset=UTF-8" />' +
        '</head>' +
        '<body>' +
        '<form action="/upload" method="post">' +
        '<textarea name="text" rows="20" cols="60"></textarea>' +
        '<input type="submit" value="Submit text" />' +
        '</form>' +
        '</body>' +
        '</html>';
    response.writeHead(200, { "Content-Type": "text/html" });
    response.write(body);
    //response.end();
}
function upload(response,postData)
{
    console.log("Your request would be pathanme upload")
    response.writeHead(203,{"Content-type":"text-plain"})
    response.write("you have text:"+postData);
    response.end()
}
function download()
{
    console.log("Your request would be pathanme download")
}
function imageUpload()
{
    console.log("Your request would be pathanme imageUpload")
}
exports.start=start
exports.upload=upload
exports.download=download
exports.imageUpload=imageUpload