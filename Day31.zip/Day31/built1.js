opeartionCount=1;
//db=db.getSiblingDB("dxcdb")
(0r)
conn = new Mongo()
db=conn.getDB("dxcdb")//
prompt=function(){
      if(typeof db == 'undefined')

{
	return 'nodb>';
}
else
{

   db='dxcdb'
}
return db + " "+(opeartionCount++)+">";	
}