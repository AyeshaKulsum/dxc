var fs=require("fs")
var fileData =fs.readFileSync("takeHomeSalary.txt","utf8")
console.log(fileData)
fs.writeFileSync("data.txt",fileData)