package com.ayesha;

/**
 * Hello world!
 *
 */
public class App 
{
	public String message(String msg)
	{
		System.out.println("message");
		return msg;
	}
    public static void main( String[] args )
    {
    	
        System.out.println( "Hello World!" );
    }
}
