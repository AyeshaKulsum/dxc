import React, { Component } from 'react';
import './../component/LoginValidation.css'
import ProductDisplay from './ProductDisplay';
import ProductDetails from './ProductDetails';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import ProductList from './ProductList';
const validateForm = (errors) => {
    let valid = true;
    Object.values(errors).forEach(
        (val) => val.length > 0 && (valid = false)
    );
    return valid;
}
class Form extends Component {
    constructor(props) {
        super(props);
        this.state = {
            productId: null,
            quantity: null,
            errors: {
                productId: '',
                quantity: '',
            },
            productList : [
                {
                    productId: 1001,
                    productName: 'Watch',
                    quantityOnHand: 2000,
                    price: 10000
                },
                {
                    productId: 1002,
                    productName: 'Mouse',
                    quantityOnHand: 29,
                    price: 180000
                },
                {
                    productId: 1003,
                    productName: 'Laptop',
                    quantityOnHand: 29,
                    price: 122
                },
                {
                    productId: 10113,
                    productName: 'Presenter',
                    quantityOnHand: 29,
                    price: 122
                },
    
                {
                    productId: 111003,
                    productName: 'Marker',
                    quantityOnHand: 29,
                    price: 122
                },
            ]
        };
        this.updateProductMethod = this.updateProductMethod.bind(this)
        this.handleChange = this.handleChange.bind(this)
        this.handleSubmit = this.handleSubmit.bind(this)
    }

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'productId':
                errors.productId =
                    value.length ===0
                        ? 'productId must not be empty!'
                        : '';
                break;
                case 'quantity':
                    errors.quantity =
                        value.length ===0
                            ? 'quantity must not be empty!'
                            : '';
                    break;
            default:
                break;
        }

        this.setState({
            errors,[name] :value
        })
    }
    handleSubmit = (event) => {
        
        event.preventDefault();
        
    }
    handleSubmit = (e) => {
        e.preventDefault()
        let productList = this.state.productList
        let updateProduct
        let toUpdateProductId 
        let toUpdateQuantityOnHand
        if(validateForm(this.state.errors))
        {
             toUpdateProductId = this.refs.productId.value
             toUpdateQuantityOnHand = this.refs.quantityOnHand.value
            
            console.log("valid Form")
            
            console.log(toUpdateQuantityOnHand)
           
            productList.map((product, index) => {
                if (product.productId == toUpdateProductId) {
                    updateProduct = this.state.productList[index]
                    console.log(updateProduct.quantityOnHand)
                    updateProduct.quantityOnHand = toUpdateQuantityOnHand
                }
            })
        }
        else
        {
            console.error("Invalid Form")
            
        }

        
        this.updateProductMethod(toUpdateProductId, toUpdateQuantityOnHand)

    }

    updateProductMethod(toUpdateProductId, toUpdateQuantityOnHand) 
    {
        var arr = this.state.productList
        arr[toUpdateProductId].quantityOnHand = toUpdateQuantityOnHand
        this.setState({
            productList: arr
        })
    }
    render() {
        let errors=this.state.errors
        return (
            <div className='wrapper'>
            <div className='form-wrapper'>
                <h2>Update Product</h2>
                <form onSubmit={this.handleSubmit} noValidate>
                    <div className='productId'>
                        <label htmlFor="productId">ProductId</label>
                        <input type='text' name='productId' placeholder="Enter productId" onChange={this.handleChange} noValidate />
                        
                        {errors.productId.length > 0 &&
                            <span className='error'>{errors.productId}</span>}
                    </div>
                    <div className='quantity'>
                        <label htmlFor="quantity">Quantity</label>
                        <input type='text' name='quantity' placeholder="Enter quantity" onChange={this.handleChange} noValidate />
                        
                        {errors.quantity.length > 0 &&
                            <span className='error'>{errors.quantity}</span>}
                    </div>
                    <div className='submit'>
                        <button className="btn btn-primary">Update</button>
                    </div>
                    <div className='info'>
                        <small>Product and Quantity should not be empty</small>
                    </div>

                </form>
              
                
            </div>
        </div>
        );
    }
}

export default Form;