package com.dxc.movie.dao;

import java.util.List;

import com.dxc.model.Movies;


public interface MovieDAO {
		public Movies getMovie(int movieId);
		public List<Movies> getAllMovies();
		public void addMovie(Movies movie);
		public void deleteMovie(int movieId);
		public void updateMovie(Movies movie);
		public boolean isMovieExists(int movieId);
}
