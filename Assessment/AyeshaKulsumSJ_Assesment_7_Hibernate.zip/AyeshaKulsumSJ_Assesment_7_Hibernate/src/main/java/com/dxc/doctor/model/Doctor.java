package com.dxc.doctor.model;

import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.search.annotations.IndexedEmbedded;


@Entity
@Table(name="Doctor")
public class Doctor {
	@Id
	private int id;
	private String name;
	private int fees; 
	@ElementCollection
	@IndexedEmbedded
	private Set<HospitalDetails> hospitalDetails;
public Doctor() {
	// TODO Auto-generated constructor stub
}
public Doctor(int id, String name, int fees, Set<HospitalDetails> hospitalDetails) {
	super();
	this.id = id;
	this.name = name;
	this.fees = fees;
	this.hospitalDetails = hospitalDetails;
}

public Doctor(String name, int fees, Set<HospitalDetails> hospitalDetails) {
	super();
	this.name = name;
	this.fees = fees;
	this.hospitalDetails = hospitalDetails;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getFees() {
	return fees;
}
public void setFees(int fees) {
	this.fees = fees;
}
public Set<HospitalDetails> getHospitalDetails() {
	return hospitalDetails;
}
public void setHospitalDetails(Set<HospitalDetails> hospitalDetails) {
	this.hospitalDetails = hospitalDetails;
}


@Override
public String toString() {
	return "Doctor [id=" + id + ", name=" + name + ", fees=" + fees + ", hospitalDetails=" + hospitalDetails + "]";
}

}
