package com.dxc.pms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dxc.pms.model.Movies;
import com.dxc.pms.service.MovieService;

@RestController
@RequestMapping("/movie")
public class MovieController {
@Autowired 
MovieService movieService;
@GetMapping("/{movieId}")
public Movies getMovie(@PathVariable("movieId")int movieId)
{
	System.out.println("Get called");
	return movieService.getMovie(movieId);
}
@DeleteMapping("/{movieId}")
public boolean deleteMovie(@PathVariable("movieId")int movieId)
{
	System.out.println("Delete called");
	return movieService.deleteMovie(movieId);
}
@GetMapping
public List<Movies> getMovies()
{
	return movieService.getMovies();
}
@PostMapping
public boolean addMovie(@RequestBody Movies movie)
{
	System.out.println(movie);
	return movieService.addMovie(movie);
}
@PutMapping
public boolean updateMovie(@RequestBody Movies movie)
{
	System.out.println(movie);
	return movieService.upadteMovie(movie);
}
}
