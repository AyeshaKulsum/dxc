import React from 'react';
import './Unlike.css';
const Unlike =(props) =>
{
return React.createElement("div",{id:"div1",className:"mydiv100"},React.createElement("h1",null,"Unlike"));
    
}
export default Unlike;