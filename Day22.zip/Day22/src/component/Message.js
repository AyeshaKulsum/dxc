import React from 'react';
export default function Welcome()
{
    return <h1>Hello</h1>
}