import axios from 'axios';
const PRODUCT_API_URL="http://localhost:8001/ProductManagementSystem/product"
class ProductDataService
{
    getAllProducts(){
        return axios.get(`${PRODUCT_API_URL}`)
    }
    deleteProduct(productId){
        return axios.delete(`${PRODUCT_API_URL}/${productId}`)
    }
    updateProduct(product){
        return axios.put(`${PRODUCT_API_URL}`,product)
    }
    getProductById(productId){
        return axios.get(`${PRODUCT_API_URL}/${productId}`)
    }
    addProduct(product){
        return axios.post(`${PRODUCT_API_URL}`,product)
    }
    getProductByName(productName){
        return axios.get(`${PRODUCT_API_URL}/search/${productName}`)
    }
    getReview(productId,reviewId)
    {
        return axios.get(`${PRODUCT_API_URL}/${productId}/reviews/${reviewId}`)
    }
    deleteReview(productId,reviewId)
    {
        return axios.delete(`${PRODUCT_API_URL}/${productId}/reviews/${reviewId}`)
    }
    getAllReviews(productId)
    {
        return axios.delete(`${PRODUCT_API_URL}/${productId}/reviews`)
    }
    addReview(productId,review)
    {
        return axios.post(`${PRODUCT_API_URL}/${productId}/reviews`,review)
    }
    updateReview(productId,review)
    {
        return axios.put(`${PRODUCT_API_URL}/${productId}/reviews`,review)
    }
}
export default new ProductDataService()