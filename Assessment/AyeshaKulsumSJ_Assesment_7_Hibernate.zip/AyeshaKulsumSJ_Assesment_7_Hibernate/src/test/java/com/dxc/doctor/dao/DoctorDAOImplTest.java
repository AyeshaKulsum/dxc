package com.dxc.doctor.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;


import com.dxc.doctor.model.Doctor;
import com.dxc.doctor.model.HospitalDetails;


import junit.framework.TestCase;

public class DoctorDAOImplTest extends TestCase {
DoctorDAOImpl daoImpl;
	protected void setUp() throws Exception {
		super.setUp();
		daoImpl=new DoctorDAOImpl();
	}

	public void testGetDoctor() {
		HospitalDetails details1=new HospitalDetails("Manipal", "Salem");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
    	Doctor doctor = new Doctor(314,"Sam", 10000000, alldetails);
    	daoImpl.addDoctor(doctor);
		Doctor doctor2=daoImpl.getDoctor(314);
		assertNotNull(doctor2);
	}

	public void testGetAllDoctors() {
		int size1=daoImpl.getAllDoctors().size();
		HospitalDetails details1=new HospitalDetails("St.Johns", "Mettur");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
    	Doctor doctor = new Doctor(213,"Kavya", 4747748, alldetails);
    	daoImpl.addDoctor(doctor);
		int size2=daoImpl.getAllDoctors().size();
		assertNotSame(size2, size1);
	}

	public void testAddDoctor() {
		List <Doctor> alldoctors=daoImpl.getAllDoctors();
		HospitalDetails details1=new HospitalDetails("St.Johns", "Mettur");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
    	Doctor doctor = new Doctor(3422,"Divya", 4747748, alldetails);
    	daoImpl.addDoctor(doctor);
    	List <Doctor> alldoctors1=daoImpl.getAllDoctors();
		
		assertNotSame(alldoctors.size(), alldoctors1.size());
	}

	public void testDeleteDoctor() {
		int size1=daoImpl.getAllDoctors().size();
		HospitalDetails details1=new HospitalDetails("St.Johns", "Mettur");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
    	Doctor doctor = new Doctor(462,"Sharmila", 4747748, alldetails);
    	daoImpl.addDoctor(doctor);
		daoImpl.deleteDoctor(462);
		int size2=daoImpl.getAllDoctors().size();
		assertEquals(size2+1, size1);
	}

	public void testUpdateDoctor() {
		HospitalDetails details1=new HospitalDetails("St.Johns", "Mettur");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
    	Doctor doctor = new Doctor(862,"Sharmila", 4747748, alldetails);
    	daoImpl.addDoctor(doctor);
		List <Doctor> alldoctors=daoImpl.getAllDoctors();
		HospitalDetails details2=new HospitalDetails("St.Johns", "Mettur");
		Set<HospitalDetails> alldetails1=new HashSet<HospitalDetails>();
    	alldetails1.add(details2);
    	Doctor doctor1 = new Doctor(862,"Kavya", 1234567, alldetails1);
    	daoImpl.updateDoctor(doctor1);
		List <Doctor> alldoctors2=daoImpl.getAllDoctors();
		assertNotSame(alldoctors2, alldoctors);
	}


	public void testSearchByName() {
		HospitalDetails details1=new HospitalDetails("Manipal", "Salem");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
    	Doctor doctor = new Doctor(67,"Sam", 10000000, alldetails);
    	daoImpl.addDoctor(doctor);
		Doctor doctor2=daoImpl.searchByName("Sam");
		assertNotNull(doctor2);
	}
	public void testIsDoctorExists() {
		HospitalDetails details1=new HospitalDetails("St.Johns", "Mettur");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
    	Doctor doctor = new Doctor(87,"Ayesha", 4747748, alldetails);
    	daoImpl.addDoctor(doctor);
		assertEquals(true, daoImpl.isDoctorExists(87));
	}
	public void testIsDoctorExists2() {
		HospitalDetails details1=new HospitalDetails("St.Johns", "Mettur");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
    	Doctor doctor = new Doctor(67122,"Ayesha", 4747748, alldetails);
    	daoImpl.addDoctor(doctor);
    	daoImpl.deleteDoctor(67122);
		assertEquals(false, daoImpl.isDoctorExists(67122));
	}
}
