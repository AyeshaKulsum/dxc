import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';
import {Formik,Form,Field, ErrorMessage} from 'formik';



class SearchComponent extends Component {
    constructor(props) {
        super(props);
        this.onSubmit=this.onSubmit.bind(this);
        this.validateProductForm=this.validateProductForm.bind(this);
        this.state=({
        
        productName:'',
        
        })
    }
    
onSubmit(product){

    console.log(product.productName);
    this.props.history.push(`/productsearch/${product.productName}`)
    
}
validateProductForm(values){
    let errors={}

    if(!values.productName){
        errors.productName='Enter a Product Name'
    }
    else if(values.productName<3)
    {
        errors.productName='Name should be greater than 3'
    }
    else if(!isNaN(values.productName))
    {
        errors.productName='Number should not be in product name'
    }
    return errors
}
    render() {
        let{productName}=this.state
        return (
            <div>
                
                <div className="container">
                <h1>Search Product</h1>
                    <Formik
                    initialValues={{productName}}
                    enableReinitialize={true}
                        onSubmit={this.onSubmit}
                        validateOnChange={false}
                        validateOnBlur={false}
                        validate={this.validateProductForm}
                        >
                        <Form>
                        
                            <ErrorMessage name="productName" component="div" className="alert alert-warning"/>
                            <fieldset className="form-group">
                                <label>Enter the product Name to search</label>
                                <Field className="form-control" type="text" name="productName"/>
                            </fieldset>
                            <button className="btn btn-warning" type="submit">Search</button>
                        </Form>
                    </Formik>
                    </div> 
            </div>
        );
    }
}

export default SearchComponent;
