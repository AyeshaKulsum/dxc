package com.dxc.doctor.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.doctor.model.Doctor;
import com.dxc.doctor.util.HibernateUtil;

public class DoctorDAOImpl implements DoctorDAO {
	SessionFactory sf =HibernateUtil.getSessionFactory();
	public Doctor getDoctor(int id) {
		Session session = sf.openSession();
		Doctor doctor =(Doctor) session.get(Doctor.class, id);
		System.out.println("Getting");
		Transaction transaction=session.beginTransaction();
		transaction.commit();
		session.close();
		return doctor;
	}

	
	public List<Doctor> getAllDoctors() {
		Session session = sf.openSession();
		Query query=session.createQuery("from Doctor");
		System.out.println("Fetching all");
		return query.list();
	}

	public void addDoctor(Doctor doctor) {
		Session session = sf.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(doctor);
		transaction.commit();
		System.out.println(doctor.getName()+" saved successfully");
		session.close();

	}

	public void deleteDoctor(int id) {
		Session session = sf.openSession();	
		Transaction transaction=session.beginTransaction();
		Doctor doctor =(Doctor) session.get(Doctor.class, id);
		session.delete(doctor);
		transaction.commit();
		System.out.println(" deleted successfully");
		session.close();

	}

	public void updateDoctor(Doctor doctor) {
		Session session = sf.openSession();
		Transaction transaction=session.beginTransaction();
		session.update(doctor);
		transaction.commit();
		System.out.println(doctor.getName()+" updated successfully");
		session.close();

	}

	public boolean isDoctorExists(int id) {
		Session session = sf.openSession();
		Doctor doctor =(Doctor)session.get(Doctor.class, id);
		if(doctor==null)
		{
			session.close();
			return false;
		}
		else
			session.close();
			return true;
	}

	public Doctor searchByName(String name) {
		Session session = sf.openSession();
		Doctor doctor =(Doctor) session.get(Doctor.class, name);
		Transaction transaction=session.beginTransaction();
		transaction.commit();
		System.out.println("Search by name");
		session.close();
		return doctor;
	}

}
