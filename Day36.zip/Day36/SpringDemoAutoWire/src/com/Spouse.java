package com;

public class Spouse {
	private String spouseName;
	public Spouse() {
		// TODO Auto-generated constructor stub
	}
	public Spouse(String spouseName) {
		super();
		this.spouseName = spouseName;
	}
	public String getSpouseName() {
		return spouseName;
	}
	public void setSpouseName(String spouseName) {
		this.spouseName = spouseName;
	}
	@Override
	public String toString() {
		return "Spouse [spouseName=" + spouseName + "]";
	}
	
}
