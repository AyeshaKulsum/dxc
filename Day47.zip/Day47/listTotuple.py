list1=[1,2,3,4,5]
list2=['a','b','c','d','e']
for t in zip(list1,list2):
    print(t)
