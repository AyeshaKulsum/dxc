package com.dxc.pms.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.dxc.pms.model.Movies;
import com.mongodb.WriteResult;
@Repository
public class MovieDAOImpl implements MovieDAO {
	@Autowired
	MongoTemplate mongoTemplate;
	@Override
	public boolean addMovie(Movies movie) {
		mongoTemplate.save(movie);
		return false;
	}

	@Override
	public Movies getMovie(int movieId) {
		
		return mongoTemplate.findById(movieId, Movies.class,"movies");
	}

	@Override
	public boolean deleteMovie(int movieId) {
		Movies movie = new Movies();
		movie.setMovieId(movieId);
		WriteResult writeResult=mongoTemplate.remove(movie);
		System.out.println(writeResult);
		int rowsAffected=writeResult.getN();
		if(rowsAffected==0)
			return false;
		else
			return true;
	}

	@Override
	public boolean upadteMovie(Movies movie) {
		mongoTemplate.save(movie);
		return false;
	}

	@Override
	public List<Movies> getMovies() {
		
		return mongoTemplate.findAll(Movies.class);
	}

	@Override
	public boolean isMovieExists(int movieId) {
		Movies movie= mongoTemplate.findById(movieId, Movies.class, "movie");
		if(movie==null)
			return false;
		else
			return true;
	}

	@Override
	public List<Movies> searchMovieByName(String movieName) {
		// TODO Auto-generated method stub
		return null;
	}

}
