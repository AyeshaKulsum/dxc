package com.dxc.doctor.dao;

import java.util.List;

import com.dxc.doctor.model.Doctor;

public interface DoctorDAO {
	public Doctor getDoctor(int id);
	public List<Doctor> getAllDoctors();
	public void addDoctor(Doctor doctor);
	public void deleteDoctor(int id);
	public void updateDoctor(Doctor doctor);
	public boolean isDoctorExists(int id);
	public Doctor searchByName(String name);
}
