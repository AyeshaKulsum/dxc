def f():
    print(s)
s="I love python"
f()
