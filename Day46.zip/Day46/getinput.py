print('Please enter some text:')
x=input()
print('Text entered:',x)
print('Type :',type(x))
