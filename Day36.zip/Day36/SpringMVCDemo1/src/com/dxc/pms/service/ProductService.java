package com.dxc.pms.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.dxc.pms.dao.ProductDAO;
import com.dxc.pms.model.Product;

public interface ProductService {
	
	public boolean addProduct(Product product);
}
