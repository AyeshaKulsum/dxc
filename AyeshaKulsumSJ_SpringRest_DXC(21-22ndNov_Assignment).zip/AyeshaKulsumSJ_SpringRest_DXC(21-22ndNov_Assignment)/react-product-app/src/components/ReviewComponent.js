import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';
import {Formik,Form,Field, ErrorMessage} from 'formik';
class ReviewComponent extends Component {
    constructor(props) {
        super(props);
        this.state=({
            productId:this.props.match.params.prodId,
            reviewId:this.props.match.params.rid,
            review:'',
            rating:'',
            disabled:'true',
            buttonName:'Update'
        })
        this.validateReviewForm=this.validateReviewForm.bind(this);
        this.onSubmit=this.onSubmit.bind(this);
    }
    componentWillMount()
    {
        if(this.state.reviewId==-1)
            {
                
                    this.setState({
                        disabled:false,
                        buttonName:'Add',
                        reviewId:''
                    })
                
                return
               
        }
        ProductDataService.getReview(this.state.productId,this.state.reviewId).then(
            response =>{
                this.setState({
                    review:response.data.review,
                    rating:response.data.rating
                })
                  console.log(this.state.reviewId) 
                }
            
        )
    }
    onSubmit(reviews){
        console.log(reviews)
        if(this.state.reviewId=='')
        {
           
            ProductDataService.addReview(this.state.productId,reviews).then(response => {
                this.props.history.push("/products");
                console.log(response);
              });
        }
        else
        {
            ProductDataService.updateReview(this.state.productId,reviews).then(
                ()=> this.props.history.push(`/products`)
             );
        }

    }
    validateReviewForm(values){
        let errors={}
        if(!values.reviewId)
        {
            errors.reviewId='Enter a Review Id'
        }
        else if(!values.review){
            errors.review='Enter a Review'
        }
        else if(!values.rating){
            errors.rating='Enter a Rating'
        }
        else if(values.rating >6){
            errors.rating='Rating should be between 1-5'
        }
        else if(isNaN(values.rating))
        {
            errors.rating='Rating should be in number'
        }
        return errors
    }
    render() {
        let{reviewId,review,rating}=this.state
        return (
            <div className="container">
                    <Formik
                        initialValues={{reviewId,review,rating}}
                        enableReinitialize={true}
                        onSubmit={this.onSubmit}
                        validateOnChange={false}
                        validateOnBlur={false}
                        validate={this.validateReviewForm}
                        >
                        <Form>
                            <ErrorMessage name="reviewId" component="div" className="alert alert-warning"/>
                            <ErrorMessage name="review" component="div" className="alert alert-warning"/>
                            <ErrorMessage name="rating" component="div" className="alert alert-warning"/>
                            <fieldset className="form-group">
                                <label>Review Id</label>
                                <Field className="form-control" type="text" name="reviewId" disabled={this.state.disabled}/>
                            </fieldset>
                            <fieldset className="form-group">
                                <label>Review</label>
                                <Field className="form-control" type="text" name="review"/>
                            </fieldset>
                            <fieldset className="form-group">
                                <label>Rating</label>
                                <Field className="form-control" type="text" name="rating"/>
                            </fieldset>
                            <button className="btn btn-success" type="submit">{this.state.buttonName}</button>
                        </Form>
                    </Formik>
                    </div> 
                
        );
    }
}

export default ReviewComponent;