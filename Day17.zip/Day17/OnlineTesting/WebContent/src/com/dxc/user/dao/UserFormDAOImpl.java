package com.dxc.user.dao;

import java.sql.Connection;

import com.dxc.pms.dbcon.DBConnection;
import com.dxc.user.model.UserForm;

public class UserFormDAOImpl implements UserFormDAO {

	Connection connection = DBConnection.getConnection();
	
	public UserFormDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addUser(UserForm userForm) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean validateUser(String username, String password) {
		return false;
	

	}

}
