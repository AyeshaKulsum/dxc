var express=require("express")
var router =express.Router()
router.get("/",function(request,response){
    response.send("Ayesha Kulsum S J")
})
module.exports=router