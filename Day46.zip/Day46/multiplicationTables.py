print('{0:>2}'.format("x"),end=' ')
for i in range(1,11):
    print('{0:>3}'.format(i),end=' ')
print("\n")
print("------------------------------------------")
for x in range(1,11):
    print('{0:>2}'.format(x),end='|')
    for y in range(1,11):
        print('{0:>3}'.format(x*y),end=' ')
    print("\n")
