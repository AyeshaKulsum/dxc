def double(n):
    return 2*n
x=double(3)
print(x)
