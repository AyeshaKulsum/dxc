import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap/dist/css/bootstrap.css' ;
import './App.css' ;
 import App from './App';
import TodoApp from './ToDoApp';
/* ReactDOM.render(<div><h1>Welcome, Ayesha</h1></div>,document.getElementById("myDiv1"));
ReactDOM.render(<div><h2>Welcome, Kulsum</h2></div>,document.getElementById("myDiv2")); */
ReactDOM.render(<TodoApp/>,document.getElementById("root"));
