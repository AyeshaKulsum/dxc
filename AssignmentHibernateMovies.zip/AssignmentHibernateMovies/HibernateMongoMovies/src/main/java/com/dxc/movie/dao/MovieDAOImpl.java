package com.dxc.movie.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.model.Movies;
import com.movie.util.HibernateUtil;

public class MovieDAOImpl implements MovieDAO {
SessionFactory sf = HibernateUtil.getSessionFactory();
	@Override
	public Movies getMovie(int movieId) {
		Session session =sf.openSession();
		Movies movie=(Movies) session.get(Movies.class, movieId);
		session.close();
		return movie;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Movies> getAllMovies() {
		Session session=sf.openSession();
		Query query=session.createQuery("from Movies");
		return query.list();
	}

	@Override
	public void addMovie(Movies movie) {
		Session session =sf.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(movie);
		transaction.commit();
		System.out.println(movie.getMovieName()+" saved successfully");
		session.close();
	}

	@Override
	public void deleteMovie(int movieId) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		Movies movie=(Movies) session.get(Movies.class, movieId);
		session.delete(movie);
		transaction.commit();
		System.out.println(" deleted successfully");
		session.close();

	}

	@Override
	public void updateMovie(Movies movie) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		session.update(movie);
		transaction.commit();
System.out.println(movie.getMovieName()+" updated successfully");
session.close();
	}

	@Override
	public boolean isMovieExists(int movieId) {
		Session session=sf.openSession();
		Movies movie=(Movies) session.get(Movies.class, movieId);
		if(movie==null)
		{
			return false;
		}
		else
		return true;
	}

}
