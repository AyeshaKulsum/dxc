function start()
{
    console.log("Your request would be pathanme start")
}
function upload()
{
    console.log("Your request would be pathanme upload")
}
function download()
{
    console.log("Your request would be pathanme download")
}
function imageUpload()
{
    console.log("Your request would be pathanme imageUpload")
}
exports.start=start
exports.upload=upload
exports.download=download
exports.imageUpload=imageUpload