import React from 'react';
const Like =(props) =>
{
return(  <div>
<h1>I liked your photo and {props.message}</h1>
    </div>)
    
}
export default Like;