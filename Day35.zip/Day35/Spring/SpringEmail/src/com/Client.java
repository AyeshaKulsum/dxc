package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Client {
public static void main(String[] args) {
	ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
	Email e =(Email) context.getBean(Email.class);
	To t =(To) context.getBean(To.class);
	From f =(From) context.getBean(From.class);
	Subject s =(Subject) context.getBean(Subject.class);
	Body b =(Body) context.getBean(Body.class);
	t.setToEmail("a@gmail.com");
	t.setToName("ayesha");
	f.setToEmail("sam@gmail.com");
	f.setToName("sam");
	s.setCaption("Hi");
	b.setMessage("Hello,welcome");
	
	System.out.println(e);
}
}

