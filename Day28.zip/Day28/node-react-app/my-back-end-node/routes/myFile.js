var express=require("express")
var router =express.Router()
router.get("/",function(request,response){
    response.send("Ayesha node")
})
module.exports=router