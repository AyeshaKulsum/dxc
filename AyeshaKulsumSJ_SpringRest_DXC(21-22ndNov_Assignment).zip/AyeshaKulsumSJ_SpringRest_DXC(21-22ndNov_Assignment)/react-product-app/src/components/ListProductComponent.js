import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';
import '../App.css';
//import 'bootstrap/dist/css/bootstrap.css';

class ListProductComponent extends Component {
    constructor(props) {
        super(props);
        this.refreshProduct = this.refreshProduct.bind(this);
        this.deleteButtonClicked = this.deleteButtonClicked.bind(this);
        this.updateButtonClicked = this.updateButtonClicked.bind(this);
        this.addButtonClicked = this.addButtonClicked.bind(this);
        this.searchButtonClicked = this.searchButtonClicked.bind(this);
        this.state = ({
            products: [],
            message: ''
        })
    }

    componentWillMount() {
        this.refreshProduct();
    }
    refreshProduct() {

        ProductDataService.getAllProducts().then(
            response => {
                this.setState({
                    products: response.data
                })

            }

        )
    }
    deleteButtonClicked(productIdToDelete) {
        ProductDataService.deleteProduct(productIdToDelete).then(
            response => {
                this.setState({
                    message: 'productId :' + productIdToDelete + ' deleted successfully'
                })
                this.refreshProduct();
            }

        )

    }
    updateButtonClicked(productIdToUpdate) {
        this.props.history.push(`/products/${productIdToUpdate}`)
    }
    addButtonClicked() {
        var productIdToAdd = -1
        this.props.history.push(`/products/${productIdToAdd}`)
    }
    searchButtonClicked() {

        this.props.history.push(`/productsearch`)

    }
    addReviewClicked(productId)
    {
        var reviewId=-1
        this.props.history.push(`/${productId}/reviews/${reviewId}`);
    }
    deleteReviewClicked(productId, reviewId)
    {
        ProductDataService.deleteReview(productId, reviewId).then(response => {
          this.setState({
            message: "Review Deleted Successfully"
          });
          this.refreshProduct();
        });
    }
    updateReviewClicked(productId, reviewId)
    {
        console.log(productId);
        console.log(reviewId);
        this.props.history.push(`/${productId}/reviews/${reviewId}`);
    }
    render() {
        return (
            <div>

                <div className="container">
                    {this.state.message && <div className="alert alert-success">{this.state.message}</div>}
                    <h3>All Products</h3>
                    <div className="container">
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>Product Id</th>
                                    <th>Product Name</th>
                                    <th>Quantity On Hand</th>
                                    <th>Price</th>
                                    <th>Reviews</th>
                                    <th>Update</th>
                                    <th>Delete</th>

                                </tr>

                            </thead>
                            <tbody>
                                {
                                    this.state.products.map(product =>
                                        <tr key={product.productId}>
                                            <td>{product.productId}</td>
                                            <td>{product.productName}</td>
                                            <td>{product.quantityOnHand}</td>
                                            <td>{product.price}</td>
                                            <td>{product.productReviews.map(review => (
                                                <tr>
                                                    <td>{review.reviewId}</td>
                                                    <td>{review.review}</td>
                                                    <td>{review.rating}</td>
                                                   
                                                    <td>
                                                        <button
                                                            className="btn btn-outline-warning btn-sm"
                                                            onClick={() =>
                                                                this.updateReviewClicked(
                                                                    product.productId,
                                                                    review.reviewId
                                                                )
                                                            }
                                                        >
                                                            Edit
                            </button>
                                                    </td>
                                                    <td>
                                                        <button
                                                            className="btn btn-outline-danger btn-sm"
                                                            onClick={() =>
                                                                this.deleteReviewClicked(
                                                                    product.productId,
                                                                    review.reviewId
                                                                )
                                                            }
                                                        >
                                                            Delete
                            </button>
                                                    </td>
                                                </tr>
                                            ))}
                                                <tr>
                                                    <button
                                                        className="btn btn-outline-info btn-sm"
                                                        onClick={() =>
                                                            this.addReviewClicked(product.productId)
                                                        }
                                                    >
                                                        Add New Review
                        </button>
                                                </tr>
                                            </td>
                                            <td><button className="btn btn-warning" onClick={() => this.updateButtonClicked(product.productId)}>Edit</button></td>
                                            <td><button className="btn btn-danger" onClick={() => this.deleteButtonClicked(product.productId)}>Delete</button></td>
                                        </tr>

                                    )
                                }
                                <tr>
                                    <td > <button className="btn btn-info" onClick={() => this.addButtonClicked()} >Add Product</button></td>

                                    <td > <button className="btn btn-primary" onClick={() => this.searchButtonClicked()}>Search Product</button></td>
                                </tr>

                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        );
    }
}

export default ListProductComponent;