package com.dxc.pms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class MyFirstController {
	@RequestMapping("/login")
	public ModelAndView gg(){
		String message="Hi,Login";
		return new ModelAndView("login","msg",message);
	}
	
	@RequestMapping("/signUp")
	public String gaag(){
		return "signUp";
	}
}
