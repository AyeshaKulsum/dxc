package com.dxc.pms.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.dxc.pms.model.Product;
@Repository
public class ProductDAOImpl implements ProductDAO {

	@Override
	public boolean addProduct(Product product) {
		System.out.println("Inside DAOImpl"+product);
		return false;
	}

	@Override
	public Product getProduct(int productId) {
		Product product=new Product(1234, "saffron", 23, 2300000);
		return product;
	}

	@Override
	public boolean isProductExists(int productId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteProduct(int productId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateProduct(Product product) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> searchProductByName(String productNameb) {
		// TODO Auto-generated method stub
		return null;
	}

}
