package com.dxc.user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dxc.pms.dbcon.DBConnection;
import com.dxc.user.model.UserForm;

public class UserFormDAOImpl implements UserFormDAO {

	Connection connection = DBConnection.getConnection();
	private static final String INSERT_USER ="insert into registration value(?,?,?,?,?,?)";
	private static final String FETCH_USER_By_Id ="select * from registration where username=? and password=?";
	public UserFormDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addUser(UserForm userForm) {
		PreparedStatement stat;
		try {
			stat = connection.prepareStatement(INSERT_USER);
			stat.setString(1, userForm.getUsername());
			stat.setString(2, userForm.getPassword());
			stat.setString(3, userForm.getConfirmpassword());
			stat.setString(4, userForm.getFullName());
			stat.setString(5, userForm.getGender());
			stat.setString(6, userForm.getQualification());
			stat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean validateUser(String username, String password) {
		boolean userExists=false;
		PreparedStatement preparedStatement;
		try
		{
		preparedStatement = connection.prepareStatement(FETCH_USER_By_Id);
		preparedStatement.setString(1, username);
		preparedStatement.setString(2, password);
		ResultSet res = preparedStatement.executeQuery();
		if(res.next())
		{
			userExists=true;
		}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return userExists;
	

	}
	
}
