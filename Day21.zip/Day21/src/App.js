import React from 'react';
import './App.css';
import Welcome from './component/Welcome';
import Message from './component/Message';
import Comment from './component/Comment';
import Like from './component/Like';
import Unlike from './component/Unlike';
import TagPeople from './component/TagPeople';
import VisitorCount from './component/VisitorCount';
import Bye from './component/Bye';
import Hello from './component/Hello';
import Hello2 from './component/Hello2';
import Chat from './component/chat';
import Chat2 from './component/Chat2';
import Lifecycle from './component/Lifecycle';
function App() {
  return (
    <div className="App">
      <Welcome name="Ayesha" place="Banglore"></Welcome>
      <Welcome name="Saif" place="Chennai"></Welcome>
      <Welcome name="Kavya" place="Banglore"></Welcome>
      <Message></Message>
      <Comment commentsText="Cool"></Comment>
      <Like message="Awesome"></Like>
      <Unlike></Unlike>
      <TagPeople friendname="Kavya"></TagPeople>
      <VisitorCount></VisitorCount>
      <Bye name="Ayesha" designation="software enginner"></Bye>
      <Hello name="Saif" designation="Developer"></Hello>
      <Hello2 name="Kavya" designation="Software"></Hello2>
      <Chat></Chat>
      <Chat2></Chat2>
      <Lifecycle commentsText="Lets read"></Lifecycle>
    </div>
  );
}

export default App;
