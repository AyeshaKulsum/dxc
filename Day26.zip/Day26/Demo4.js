var fs=require("fs")
//sync deleting
/* fs.unlinkSync("data.txt")
console.log("Done") */
//async deleting
fs.unlink("takeHomeSalary.txt",function(error){

});
