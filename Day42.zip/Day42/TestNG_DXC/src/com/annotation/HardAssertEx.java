package com.annotation;

import org.testng.Assert;
import org.testng.annotations.Test;

public class HardAssertEx {
	@Test
public void testcase1() {
	int Explinks=10;
	int Actlinks=12;
	System.out.println("A");
	try {
		Assert.assertEquals(Actlinks, Explinks);
	} catch (Throwable t) {
		System.out.println(t.getMessage());
	}
	System.out.println("B");
}
}
