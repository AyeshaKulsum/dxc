package com;

import com.ahmed.App;

public class Main {
public static void main(String[] args) {
	 App app =new App();
	 System.out.println(app.message(" Hello World"));
	 
}
}
