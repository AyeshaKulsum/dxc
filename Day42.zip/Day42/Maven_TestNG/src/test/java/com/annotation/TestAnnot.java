package com.annotation;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestAnnot {
	
	@Test
public void testcase1()
{
		//compose mail
	System.out.println("compose mail");
}
	@BeforeMethod
	public void beforemethod()
	{
			//before method
		System.out.println("Open Browser,url,login");
	}
	@AfterMethod
	public void aftermethod()
	{
			//after method
		System.out.println("logout,close Browser");
	}
	@BeforeClass
	public void beforeclass()
	{
			//before class
		System.out.println("Open server");
	}
	@AfterClass
	public void afterclass()
	{
			//after class
		System.out.println("Close server");
	}
	@Test
public void testcase2()
{
		//save mail
	System.out.println("save mail");
}
	@Test
public void testcase3()
{
		//delete mail
	System.out.println("delete mail");
}
}
