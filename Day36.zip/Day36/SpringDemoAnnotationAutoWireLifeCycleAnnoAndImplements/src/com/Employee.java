package com;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

public class Employee implements InitializingBean,DisposableBean{
	private int empId;
	private String empName;
	private int salary;
	@Autowired(required=false)
	private Address address;
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(int empId, String empName, int salary, Address address) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.address = address;
	}

@PostConstruct
public void start1()
{
	System.out.println("########STARTED via annotation");
}
@PreDestroy
public void end1()
{
	System.out.println("########END via annotation");
}

	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", salary=" + salary + ", address=" + address
				+ "]";
	}
	@Override
	public void destroy() throws Exception {
		System.out.println("Destroy via implements");
		
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Init via implements");
		
	}
	
}
