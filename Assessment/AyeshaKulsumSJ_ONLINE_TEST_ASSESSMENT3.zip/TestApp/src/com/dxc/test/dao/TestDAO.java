package com.dxc.test.dao;


public interface TestDAO {
	public void calculate(int count);
	public boolean validateUser(String question,String answer);
}
