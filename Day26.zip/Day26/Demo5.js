var fs=require('fs')
fs.mkdir('stuff',function(){
    fs.readFile("readme.txt",'utf-8',function(err,data){
        fs.writeFileSync('./stuff/writeMe.txt',data)
    })
})