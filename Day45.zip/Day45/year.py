# Read an integer:
# a = int(input())
# Print a value:
# print(a)
day = int(input())
remainder=day%7
if(remainder==1):
  print(4)
elif(remainder==2):
  print(5)
elif(remainder==3):
  print(6)
elif(remainder==4):
  print(0)
elif(remainder==5):
  print(1)
elif(remainder==6):
  print(2)
elif(remainder==0):
  print(3)
  
