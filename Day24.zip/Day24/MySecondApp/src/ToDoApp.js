import React, { Component } from 'react'
import TodoList from './TodoList';
import 'bootstrap/dist/css/bootstrap.css' ;
import './App.css' ;
class TodoApp extends Component
{
    constructor(props) 
    {
        super(props);
        this.state = {
            items: [],
            text: '',
            description:''
            
        }
        this.onChange1=this.onChange1.bind(this)
        this.onChange2=this.onChange2.bind(this)
        this.handleSubmit=this.handleSubmit.bind(this)
    }

    onChange1(e) {
        this.setState({text: e.target.value,
            
        })
    }
    onChange2(e) {
        this.setState({
            description:e.target.value
        })
    }

    handleSubmit(e) 
    {
        e.preventDefault();
        var nextItems = this.state.items.concat([this.state.text]).concat([this.state.description]);
        var nextText = '';
        var nextDescription = '';
        this.setState({items: nextItems, text: nextText,description:nextDescription});
    }

    render() {
    
        return (
            
       
            
            <form onSubmit={this.handleSubmit}>
        <div>
        
            <h3>Company</h3>
            
           
                <input onChange={this.onChange1} value={this.state.text} placeholder="Name" />
                <input onChange={this.onChange2} value={this.state.description} placeholder="Description" />
                <button className="btn-success">{'Add #' + (this.state.items.length + 1)}</button>
              <div ><TodoList items={this.state.items} /></div>  
            
        </div>
        </form>
        );
    }
}
export default TodoApp
