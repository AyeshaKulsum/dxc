def equals(a,b,tolerance):
    return a==b or fabs(a-b) < tolerance
