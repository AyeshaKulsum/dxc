import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';
import {Formik,Form,Field, ErrorMessage} from 'formik';

class ProductComponent extends Component {
    constructor(props) {
        super(props);
        this.state=({
            productId:this.props.match.params.prodId,
            productName:'',
            quantityOnHand:'',
            price:'',
            disabled:'true',
            buttonName:'Update'
        })
this.validateProductForm=this.validateProductForm.bind(this);
this.onSubmit=this.onSubmit.bind(this);

    }
    componentWillMount()
    {
        if(this.state.productId==-1)
            {
                
                    this.setState({
                        disabled:false,
                        buttonName:'Add',
                        productId:''
                    })
                
                return
               
        }
       
        
            ProductDataService.getProductById(this.state.productId).then(
                response =>{
                    this.setState({
                        productName:response.data.productName,
                        quantityOnHand:response.data.quantityOnHand,
                        price:response.data.price
                    })
                        console.log(this.state.price);
                    }
                
            )
            }
  
    onSubmit(product){
        console.log(product)
        if(this.state.productId=='')
        {
           
            ProductDataService.addProduct(product).then(response => {
                this.props.history.push("/products");
                console.log(response);
              });
        }
        else
        {
            ProductDataService.updateProduct(product).then(
                ()=> this.props.history.push(`/products`)
             );
        }

    }

    validateProductForm(values){
        let errors={}
        if(!values.productId)
        {
            errors.productId='Enter a Product Name'
        }
        else if(!values.productName){
            errors.productName='Enter a Product Name'
        }
        else if(!values.quantityOnHand){
            errors.productName='Enter a Quantity On Hand'
        }
        else if(!values.price){
            errors.productName='Enter a Price'
        }
        else if(values.price <0){
            errors.productName='Price should not be negative'
        }
        else if(values.productName<3)
        {
            errors.productName='Name should be greater than 3'
        }
        else if(!isNaN(values.productName))
        {
            errors.productName='Number should not be in product name'
        }
        return errors
    }
    render() {
        let{productId,productName,quantityOnHand,price,initialValues}=this.state

            return (
                <div>
             {   /*    <h1>Add/Update</h1>
                    <h3>Id to update{productId}</h3>
                    <h3>{productName}
                    </h3>
                    <div>{quantityOnHand}</div>
                    <div>{price}</div>*/}
                    <div className="container">
                    
                    <Formik
                        initialValues={{productId,productName,quantityOnHand,price}}
                        enableReinitialize={true}
                        onSubmit={this.onSubmit}
                        validateOnChange={false}
                        validateOnBlur={false}
                        validate={this.validateProductForm}
                        >
                        <Form>
                            <ErrorMessage name="productId" component="div" className="alert alert-warning"/>
                            <ErrorMessage name="productName" component="div" className="alert alert-warning"/>
                            <ErrorMessage name="quantityOnHand" component="div" className="alert alert-warning"/>
                            <ErrorMessage name="price" component="div" className="alert alert-warning"/>
                            <fieldset className="form-group">
                                <label>Product Id</label>
                                <Field className="form-control" type="text" name="productId" disabled={this.state.disabled}/>
                            </fieldset>
                            <fieldset className="form-group">
                                <label>Product Name</label>
                                <Field className="form-control" type="text" name="productName"/>
                            </fieldset>
                            <fieldset className="form-group">
                                <label>Quantity On Hand</label>
                                <Field className="form-control" type="text" name="quantityOnHand"/>
                            </fieldset>
                            <fieldset className="form-group">
                                <label>Price</label>
                                <Field className="form-control" type="text" name="price"/>
                            </fieldset>
                            <button className="btn btn-warning" type="submit">{this.state.buttonName}</button>
                        </Form>
                    </Formik>
                    </div> 
                </div>
            );
         
        

    }
}

export default ProductComponent;