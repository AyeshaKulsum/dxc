import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
ReactDOM.render(<div><h1>Welcome, Ayesha</h1></div>,document.getElementById("myDiv1"));
ReactDOM.render(<div><h2>Welcome, Kulsum</h2></div>,document.getElementById("myDiv2"));
ReactDOM.render(<App/>,document.getElementById("root"));