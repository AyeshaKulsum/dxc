def process(a,b,c):
    print('a=',a,'b=',b,'c=',c)
x=14
process(1,2,3)
process(a=10,b=20,c=30)
process(b=10,c=20,a=30)
process(c=3000,a=1000,b=2000)
process(10000,c=30000,b=20000)
