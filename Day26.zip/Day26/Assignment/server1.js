var http=require("http")
var server =http.createServer(function(request,response){
    response.writeHead(200,{"Content-type":"text-plain"})
    response.write("Today is monday")
    response.end()
});
server.listen(8888)
console.log("Server started on port 8888")