package msn;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Msn {
	public WebDriver driver;
	public String Browser="chrome";
	@Test
	public void testcase1() throws Throwable{
		SoftAssert st=new SoftAssert();
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver=new ChromeDriver(); //OpenBrowser
		}else if(Browser.equalsIgnoreCase("mozilla")){
			System.setProperty("webdriver.firefox.marionette", "geckodriver.exe");
			 driver=new FirefoxDriver();
		}else if(Browser.equalsIgnoreCase("ie")){
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			 driver=new InternetExplorerDriver();
		}
		
		driver.get("https://www.msn.com"); //open url
		
		driver.manage().window().maximize(); //maximize browser
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//Go to one note and enter number
		
		driver.findElement(By.xpath("//h3[contains(text(),'OneNote')]")).click();
		Set<String> allids=driver.getWindowHandles();
		Iterator<String> it=allids.iterator();
		String mid=it.next();
		String t1=it.next();
		driver.switchTo().window(t1);
		driver.findElement(By.xpath("//input[@id='i0116']")).sendKeys("876556655");
		Thread.sleep(3000);
		//close one note
		driver.close();
		driver.switchTo().window(mid);
		Thread.sleep(3000);
		//open skype
		driver.findElement(By.xpath("//h3[contains(text(),'Skype')]")).click();
		Thread.sleep(3000);
		//close browser
		driver.quit();
		//driver.close();
		//st.assertAll();
}
}
