package com.dxc.entity;

import java.util.HashSet;
import java.util.Set;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


import com.pms.util.HibernateUtil;

public class Client {
public static void main(String[] args) {
	SessionFactory factory=HibernateUtil.getSessionFactory();
	Session session =factory.openSession();
	Transaction transaction = session.beginTransaction();
	BillAmount bill1 =new BillAmount(1, 100, 100, 9700);
	BillAmount bill2 =new BillAmount(2, 100, 100, 6700);
	BillAmount bill3 =new BillAmount(3, 100, 100, 4600);
	Set<BillAmount> allbill=new HashSet<BillAmount>();
	allbill.add(bill1);
	allbill.add(bill2);
	allbill.add(bill3);
	Customer customer=new Customer("Ayesha", allbill);
	session.save(customer);
	transaction.commit();
	System.out.println("Its Done");
}
}
